/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#ifndef _IR_THREAD_H    /* Guard against multiple inclusion */
#define _IR_THREAD_H

#include "uart_thread.h"
#include "queue.h"
#include <stdio.h>
#include <stdlib.h>

    
typedef struct {
    /* Describe structure member. */
    QueueHandle_t IRQueue;
     volatile uint32_t IR_value;
     int i;
     uint32_t IRdist;
    /* Describe structure member. */
    bool some_flag;

} IR_DATA;
IR_DATA IR;

//struct IR_message
//{

//} IRMessage;

void IR_Initialize(void);
//void IR_queue_create (void);
void IR_Tasks(void);
void distance_data_send(uint32_t d);
    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
