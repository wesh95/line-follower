#include "IR_thread.h"

void IR_Initialize(void)
{
    //IR_queue_create();
    DRV_ADC_Initialize();//needed?
    DRV_ADC_Open();
    PLIB_ADC_SampleAutoStartEnable(ADC_ID_1);
    IR_queue_create();
}

void IR_queue_create (void){
	 IR.IRQueue = xQueueCreate( 2, sizeof(uint32_t));
     xQueueReset(IR.IRQueue);
}

void IR_Tasks(void)
{
    vTaskDelay(100);
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_ADC_1);
    SYS_INT_SourceEnable(INT_SOURCE_USART_1_TRANSMIT);
    if( xQueueReceive( IR.IRQueue, ( void * ) &IR.IRdist, portMAX_DELAY ) );
    SYS_INT_SourceDisable(INT_SOURCE_USART_1_TRANSMIT);
    IR.IRdist = IR.IRdist/16;
    //IR.IRdist = 3200/IR.IRdist;
    if(IR.IRdist > 1024)
        IR.IRdist = 1024;
    if(IR.IRdist < 0)
        IR.IRdist = 0;
    distance_data_send(IR.IRdist);
    //dbgOutputVal(IR.IR_value);
}


//distance_data_send((uint32_t) IR.IR_value);

/* *****************************************************************************
 End of File
 */
